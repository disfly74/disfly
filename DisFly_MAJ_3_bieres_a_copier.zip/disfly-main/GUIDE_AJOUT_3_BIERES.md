# DISFLY — MISE À JOUR 3 BIÈRES (123 → 126 PRODUITS)

**À partir du ZIP final `DisFly_site_complet_123_produits.zip`**.

### Installation sur le site existant

1. Faites une sauvegarde de votre dossier `disfly-main` (le site actuel).
2. Décompressez ce ZIP.
3. Ouvrez le dossier `disfly-main` fourni dans le ZIP.
4. **Copiez son contenu** dans le dossier `disfly-main` de votre site final, au même niveau que `index.html` et `catalogue.html`.
5. Si l’ordinateur demande si vous souhaitez **remplacer les fichiers existants**, répondez **Oui**.
6. Vérifiez localement `catalogue.html` et `grossiste-bieres.html`, puis publiez l’ensemble sur votre hébergement.

**Attention :** ne copiez pas le dossier `disfly-main` *à l’intérieur* d’un autre dossier `disfly-main`. Il faut fusionner leurs contenus.

### Les trois produits ajoutés

| Référence | Format | Alcool | Catégorie |
| --- | --- | --- | --- |
| Amsterdam Navigator | Canette 50 cl | 8 % vol. | Bières |
| La Goudale Blonde | Canette 50 cl | 7,2 % vol. | Bières |
| Amsterdam Maximator | Canette 50 cl | 11,6 % vol. | Bières |

### Fichiers à ajouter (nouveaux)

- `amsterdam-navigator-biere-canette-50cl.webp`
- `amsterdam-maximator-biere-canette-50cl.webp`
- `la-goudale-blonde-biere-canette-50cl.webp`
- `produit-amsterdam-navigator-biere-canette-50cl.html`
- `produit-amsterdam-maximator-biere-canette-50cl.html`
- `produit-la-goudale-blonde-biere-canette-50cl.html`
- `grossiste-amsterdam.html` (page marque)

### Fichiers à remplacer (modifiés)

- `catalogue.html` (les 3 cartes produits ; total 126 références)
- `grossiste-bieres.html` (3 nouvelles cartes ; 18 bières)
- `marques.html` (Amsterdam et La Goudale)
- `products-seo.json` (les données des 3 références)
- `sitemap.xml` (les 4 nouvelles URLs + images)

### SEO intégré

Chaque fiche produit comporte un titre et une méta-description propres, une URL propre, une balise canonique, Open Graph, une image WebP et ses textes alt, des données structurées Product et BreadcrumbList, ainsi que des liens vers la catégorie. La marque Amsterdam dispose d’une page SEO dédiée.

**Aucun prix, stock ni colisage carton n’a été inventé.** Après publication, vous pouvez soumettre `https://www.disfly.fr/sitemap.xml` à Google Search Console. Google reste libre du délai et de l’indexation.
